<template>
  <el-container style="height: 100%; border: 1px solid #eee">
    <el-row class="tac">
      <el-col :span="50">
        <h5>默认颜色</h5>
        <el-menu
          default-active="2"
          class="el-menu-vertical-demo"
          @open="handleOpen"
          @close="handleClose"
          background-color="#545c64"
          text-color="#fff"
          active-text-color="#ffd04b">

          <router-link to="/vip">
            <el-menu-item index="1" >
              <i class="el-icon-menu"></i>
              <span slot="title">会员管理</span>
            </el-menu-item>
          </router-link>
          <router-link to="/employee">
          <el-menu-item index="2" >
            <i class="el-icon-document"></i>
            <span slot="title">员工管理</span>
          </el-menu-item>
          </router-link>
          <router-link to="/equipment">
          <el-menu-item index="3">
            <i class="el-icon-setting"></i>
            <span slot="title">器材管理</span>
          </el-menu-item>
          </router-link>
          <router-link to="/course">
            <el-menu-item index="4">
              <i class="el-icon-setting"></i>
              <span slot="title">课程管理</span>
            </el-menu-item>
          </router-link>
        </el-menu>
      </el-col>
    </el-row>


    <el-container>
      <el-header style="text-align: right; font-size: 12px">
        <el-dropdown>
          <i class="el-icon-setting" style="margin-right: 15px"></i>
          <el-dropdown-menu slot="dropdown">
            <el-dropdown-item>
              <el-link @click="fnLogout">注销</el-link>


            </el-dropdown-item>
          </el-dropdown-menu>
        </el-dropdown>
        <span>{{user.username}}</span>
      </el-header>

      <el-main>
        <router-view></router-view>
      </el-main>
    </el-container>
  </el-container>
</template>

<script>
import axios from "axios";
export default {
  name: "main",
  data() {
    return {
      user : [] =this.$route.query.user,
      list:[]
    }
  },
  mounted() {

    axios.get("user/init?username=" + this.user)
      .then(res =>{

        this.list = res.data.data;
        console.log(this.list);



      })
  }
  ,
  methods:{
    fnLogout(){
      alert(111)
    }
  }
};
</script>

<style scoped>

</style>
