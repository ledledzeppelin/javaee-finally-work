<template>

</template>

<script>
export default {
  name: "personal"
}
</script>

<style scoped>

</style>
